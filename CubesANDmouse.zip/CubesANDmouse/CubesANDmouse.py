
import pygame
from pygame import font
from random import randint as rnd
import os

pygame.init()

WIDTH:int = 1000
HEIGHT:int = 1000
size = (WIDTH, HEIGHT)
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
done = False

cubes = pygame.sprite.Group()
class Element():
    def __init__( self,ir, zr):
        x = ir*100
        y = zr*100
        a=rnd(0,2)
        
        my_image_path = os.path.join('R.jpg')
        

        my_image = pygame.image.load(my_image_path).convert_alpha()
        
        self.image = my_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.col=0
    def update(self):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.x == (event.pos[0]//100)*100 and self.rect.y == (event.pos[1]//100)*100:
                print("yes")
                if self.col==0:
                    my_image_path = os.path.join('W.jpg')
                    self.col=1
                elif self.col==1:
                    my_image_path = os.path.join('B.jpg')
                    self.col=2
                elif self.col==2:
                    my_image_path = os.path.join('R.jpg')
                    self.col=0
                my_image = pygame.image.load(my_image_path).convert_alpha()
                self.image = my_image
            
        
for z in range(10):
    for i in range(10):
        
        
        
        cube = Element(i,z)
        cubes.add_internal(cube)
        

while not done:
    clock.tick(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            print(event.pos, event.button)
            pass
        


    screen.fill(pygame.Color('black'))
    cubes.update()
   
    cubes.draw(screen)
    pygame.display.flip()
pygame.quit()
